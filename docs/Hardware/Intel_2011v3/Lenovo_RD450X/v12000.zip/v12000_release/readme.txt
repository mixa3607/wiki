; ASPEED iRMP SOC Flash Package Description
;===============================================================================
1.Package Description:
- socflash.zip: for DOS Execution Environment
- winflash.zip: for Windows Execution Environment
- lxflash.tar.gz: for x86/x64 Linux Execution Environment
- bsdflash.tar.gz: for FreeBSD Execution Environment
- uflash_x64.zip: for x64 UEFI Shell Execution Environment
2.Usage Description:
- See readme.txt in each compressed package
3.Contact Window:
- yc_chen@aspeedtech.com
- 886.3.578.9568 ext. 810
